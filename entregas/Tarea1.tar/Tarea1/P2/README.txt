Nombre: mfau: most frequent Aragorn users
Sintaxis: mfau
Descripción: mfau retorna el listado de usernames de los usuarios lisados por last desde el que
tuvo más accesos al de menor número de accesos. En cada línea se muestra además el número de
accesos.

Contenido:
- README.txt	este archivo
- mfau.sh	script

//////////////////////   INSTRUCCIONES   //////////////////////

1) Situar el archivos 'mfau.sh' en un directorio con permisos de lectura.
2) Para ejecutarlo directamente se deben dar permisos de ejecución, por ejemplo:
	$chmod u+x mfau.sh
	$mfau.sh
   Alternativamente puede ejecutarse utilizando el comando bash, lo que requiere permisos de lectura
   sobre el archivo, por ejemplo:
	$bash mfau.sh