Nombre: lnbf: List the biggest n files under a given directory
Sintaxis: lnbf <n> [directory]
Descripción: lnbf es un script bash que lista los n archivos más grandes bajo el directorio. Cuando
el directorio es omitido, se aplica sobre el directorio actual. Si hay menos de n archivos, lista los
que encuentre. El listado incluye en cada línea el tamaño, luego el path completos del archivo y
finalmente su fecha del último acceso. El listado muestra los archivos desde el más grande al más
pequeño.

Contenido:
- README.txt	este archivo
- lnbf.sh	script

//////////////////////   INSTRUCCIONES   //////////////////////

1) Situar el archivos 'lnbf.sh' en un directorio con permisos de lectura.
2) Para ejecutarlo directamente se deben dar permisos de ejecución, por ejemplo:
	$chmod u+x lnbf.sh
	$lnbf.sh <n> [directory]
   Alternativamente puede ejecutarse utilizando el comando bash, lo que requiere permisos de lectura
   sobre el archivo, por ejemplo:
	$bash lnbf.sh <n> [directory]