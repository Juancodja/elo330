Nombre: tldau: top-level domain name of Aragorn users
Sintaxis: tdlau
Descripción: Retorna la lista de nombres de dominio de nivel superior (ej. cl, uk, us, edu) de los
usuarios de aragorn listados por last. Cada línea del listado muestra el número de accesos y el
dominio. El listado muestra desde el dominio de mayor al de menor acceso.

Contenido:
- README.txt	este archivo
- ldlau.sh	script

//////////////////////   INSTRUCCIONES   //////////////////////

1) Situar el archivos 'ldlau.sh' en un directorio con permisos de lectura.
2) Para ejecutarlo directamente se deben dar permisos de ejecución, por ejemplo:
	$chmod u+x ldlau.sh
	$ldlau.sh
   Alternativamente puede ejecutarse utilizando el comando bash, lo que requiere permisos de lectura
   sobre el archivo, por ejemplo:
	$bash ldlau.sh